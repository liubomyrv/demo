﻿All files in this directory (Modelica) and in all subdirectories,
especially in Modelica/Resources/* are licensed
by the Modelica Association under the Modelica License 2
(with exception of files "Modelica/Resources/C-Sources/win32_dirent.*, ModelicaMatIO.*, ModelicaStandardTables.*").
Copyright © 1998-2013, ABB, Austrian Institute of Technology, T. Boedrich, DLR, Dassault Systemes AB,
                       Fraunhofer, A. Haumer, ITI, C. Kral, Modelon, TU Hamburg-Harburg, Politecnico di Milano,
                       XRG Simulation.

These files are free software and the use is completely at your own risk;
they can be redistributed and/or modified under the terms of the
Modelica license 2, see the license conditions (including the disclaimer of warranty)
in file Modelica/Resources/Documentation/ModelicaLicense2.html
or at http://www.modelica.org/modelica-legal-documents/ModelicaLicense2.html.

Licensor:
Modelica Association
(Ideella Föreningar 822003-8858 in Linköping)
c/o PELAB, IDA, Linköpings Universitet
S-58183 Linköping
Sweden
email: Board@Modelica.org
web  : http://www.Modelica.org
