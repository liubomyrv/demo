This directory contains Microsoft Visual Studio projects to construct object
libraries from the C-code under Resources/C-Sources

- ModelicaStandardTables.lib
  This library contains
  Resources/C-Sources/ModelicaStandardTables.c
                     /ModelicaMatIO.c

- The LIB Release configuration builds a static library (*.lib) with /MT
  and can therefore be used with Dymola.
